#MSc Thesis Title: The Role of the Mother in Feeding Skill Acquisition in Immature Sumatran Orangutans_RScript_Mikeliban, Mulati (ID 3755188)
#Supervisors: Dr. Caroline Schuppli; Dr. Robert Hepach 
###########################################################################################################################################

# set working directory
setwd("C:/Users/Mikeliban/MSc Thesis/")

#the following shows three parts
###############################################part one####################################################################################
#begging success models in wild, zoo, and full datasets
#all the packages I need:
library(car)
library(lme4)
library(ggplot2)
library(effects)
library(psych)
library(plotrix)
library(wesanderson)
###########################################################################################################################################
#the followings contain three models: wild, zoo, and full models                                                                          #             
#important: in the following, "Begger" always refers to "Focal"; "Rarity" always refers to "Frequency" of the food item in this thesis    #
###########################################################################################################################################
# wild model: model i
# read my wild table. 
wild<-read.delim("Data II_Subset_wild_ExactAge.txt", header=T, sep="\t", na.strings=c("", "NA"))
str(wild)
# subset the data with the begging targets being the mothers only.
wild_mo<-subset(wild,RelationtoB=="mother")
str(wild_mo)
# handle the missing data [only for fitting the model!]
wild_mo=wild_mo[!is.na(wild_mo$Success),]
wild_mo=wild_mo[!is.na(wild_mo$ExactAge),]
wild_mo=wild_mo[!is.na(wild_mo$FoodItem),]
wild_mo=wild_mo[!is.na(wild_mo$Mother),]
wild_mo=wild_mo[!is.na(wild_mo$Complexity),]
wild_mo=wild_mo[!is.na(wild_mo$Rarity),]
wild_mo=wild_mo[!is.na(wild_mo$Begger.id),]
str(wild_mo)
wild_mo$Success=as.factor(wild_mo$Success)
wild_mo$Sex<-as.factor(wild_mo$Sex)
wild_mo$FoodItem<-as.factor(wild_mo$FoodItem)
wild_mo$Mother<-as.factor(wild_mo$Mother)
wild_mo$Begger.id<-as.factor(wild_mo$Begger.id)
#dummy code Success: 0=unsuccessful, 1=successful.
wild_mo$Success=as.numeric(wild_mo$Success)
wild_mo$Success[wild_mo$Success==1]<-0
wild_mo$Success[wild_mo$Success==2]<-1
#random effects in the model: focal ID ("Begger"), "Mother", & food item ID "Food item" 
#preparatory steps
#are the data balanced in each of those?
table(wild_mo$Begger.id)
table(wild_mo$Mother)
table(wild_mo$FoodItem)
#all not really balanced.
#check the frequency of success per chimp ID and food item
table(wild_mo$Success,wild_mo$Begger.id)
table(wild_mo$Success,wild_mo$FoodItem)
#check the distributions of the covariates: ExactAge, AgeClass, Complexity, Rarity. 
hist(wild_mo$ExactAge)
hist(sqrt(wild_mo$ExactAge))
hist(wild_mo$AgeClass)
hist(wild_mo$Complexity)
hist(wild_mo$Rarity)
#only the complexity seems okay-ish.
#inspect the food items and focal: could there be a special taste of food of some individuals?
table(wild_mo$FoodItem,wild_mo$Begger.id)
table(wild_mo$Begger.id,wild_mo$ExactAge)
table(wild_mo$Begger.id,wild_mo$Mother)
#they are both partly crossed.
######################################################################################################################################
#fit the model
contr=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=100000))
wild_mo$BeggerAge=as.factor(paste(wild_mo$Begger.id,round(wild_mo$ExactAge)))
hist(wild_mo$ExactAge)
describe(wild_mo$ExactAge)
hist(sqrt(wild_mo$ExactAge))
describe(sqrt(wild_mo$ExactAge))
#nice, keep the 'sqrt.Age'
hist(wild_mo$Complexity)
describe(wild_mo$Complexity)
#keep it as it is.
hist(wild_mo$Rarity)
describe(wild_mo$Rarity)
hist(sqrt(wild_mo$Rarity))
describe(sqrt(wild_mo$Rarity))
#not super ideal but much better! Keep it as 'sqrt.Rarity'!
wild_mo$sqrt.Rarity=sqrt(wild_mo$Rarity)
wild_mo$sqrt.Age=sqrt(wild_mo$ExactAge)
#raw data with the age plot.
ggplot(wild_mo, aes(x =sqrt.Age, y =Success)) +theme(text = element_text(size = 20))+
     geom_jitter(height = 0.01, width = 0) + labs(y="Success (0 = unsuccessful, 1 = successful)",x = "Age (square root transformed)")+
     geom_smooth(method = "loess", size = 1,col="purple")+theme_bw()+coord_cartesian(ylim = c(0, 1), xlim = c(0.5, 4))
#this indicates that the relation between the age and success is negative quadratic.
#To see if age has a linear or quadratic effect on success you can compare two models with the anova function:1. Success ~ Age + (1|Individual) and 2. Success~ Age + I(Age^2) + (1|Individual) -> if Nr 2. is preferred you can include age like this in the full model. 
is.ExactAge.linear.v1<- glmer(Success ~ ExactAge + (1|BeggerAge) +(1|Mother/Begger.id),family=binomial(link="logit"), data=wild_mo, control=contr)
is.ExactAge.linear.v2<- glmer(Success ~ ExactAge + I(ExactAge^2)+(1|BeggerAge) +(1|Mother/Begger.id),family=binomial(link="logit"), data=wild_mo, control=contr)
anova(is.ExactAge.linear.v1,is.ExactAge.linear.v2,test="Chisq")
#'is.ExactAge.linear.v2' is preferred! So include age as a quadratic variable in the model.
interaction<- glmer(Success ~ sqrt.Age + Sex + sqrt.Age * Sex + Complexity + sqrt.Rarity+I(sqrt.Age^2) + 
           (1|BeggerAge) + (1|Mother/Begger.id) + 
           (0 + sqrt.Age|Mother/Begger.id) +(0 + Sex|Mother/Begger.id)+(1|FoodItem) + 
           (0 + Complexity | FoodItem)+(0 + sqrt.Rarity| FoodItem),family=binomial(link="logit"),
           data=wild_mo,control=contr)
# Check residuals and residuals vs. fitted vallues.
hist(residuals(interaction))
qqplot(residuals(interaction), rnorm(length(residuals(interaction))))
qqline(residuals(interaction), rnorm(length(residuals(interaction))),col = "dodgerblue", lwd = 2)
plot(fitted(interaction),residuals(interaction))
#to get LRT, df, and p results:
drop1(interaction, test="Chisq")
#to get estimates and SE
round(summary(interaction)$coefficients,3)
#to get sd for random effects:
summary(interaction)$varcor
#to get CIs
int1 <- predictorEffect("Complexity", interaction, focal.levels=6)
summary(as.data.frame(int1))
int2 <- predictorEffect("sqrt.Rarity", interaction)
summary(as.data.frame(int2))
int3 <- predictorEffect("sqrt.Age", interaction)
summary(as.data.frame(int3))
int4<- predictorEffect("Sex", interaction)
summary(as.data.frame(int4))
#plot the significant results: Age, complexity and the interaction between age and sex. 
plot(allEffects(interaction),ylab="Probability of Begging Success",selection=1) #->complexity.
plot(allEffects(interaction),xlab="Age (square root transformed)",ylab="Probability of Begging Success",selection=3) #-> age
#age and sex as an interaction effect on the begging success.
a.s0<- predictorEffect("sqrt.Age",interaction)
plot(a.s0, lines=list(multiline=TRUE, col=c("magenta","blue")),confint=list(style="auto"),xlab="Age (square root transformed)", ylab="Probability of Begging Success")
###############################################################################################################################################
#there is a singular fit issue in the wild model (interaction), is it a big problem?
summary(interaction)$varcor 
ll.old=logLik(interaction)
round(ll.old, 3); logLik(interaction)
#exclude random slopes for ExactAge
interaction.s<- glmer(Success ~ ExactAge + Sex + ExactAge*Sex+Complexity + Rarity + I(ExactAge^2)+(1|BeggerAge)+ (1|FoodItem)+ (0+Complexity|FoodItem)+(0+Rarity|FoodItem),family=binomial(link="logit"), data=wild_mo, control=contr)
#it worked! Let's see if they are actually very different
summary(interaction.s)$varcor  
logLik(interaction); logLik(interaction.s)
round(summary(interaction)$coefficients,3)
round(summary(interaction.s)$coefficients,3)
#they are exactly the same so just keep the original since it is more informative.
#collinearity
co=lm(Success ~ sqrt.Age + Sex +Complexity + sqrt.Rarity , data=wild_mo)
vif(co)
#since there is overlap and rather small variation of age within sexes so it makes sense to include them as an interaction.
#############################################################################################################################################
#Results
#individual predictors
round(summary(interaction)$coefficients,3)
#intercepts
exp(fixef(interaction)["(Intercept)"])/(1+exp(fixef(interaction)["(Intercept)"]))
#check the random effects
summary(interaction)$varcor
################################################################################################################################################
#zoo model: model iii
zooage<-read.delim("Data III_Subset_zoo_ExactAge.txt", header=T, sep="\t",na.strings=c("", "NA"))
str(zooage) 
# subset the data with the begging targets being the mothers only.
zoo_mo<-subset(zooage,RelationtoB=="mother")
str(zoo_mo)
zoo_mo=zoo_mo[!is.na(zoo_mo$Success),]
zoo_mo=zoo_mo[!is.na(zoo_mo$ExactAge),]
zoo_mo=zoo_mo[!is.na(zoo_mo$Sex),]
zoo_mo=zoo_mo[!is.na(zoo_mo$Complexity),]
zoo_mo=zoo_mo[!is.na(zoo_mo$Rarity),]
zoo_mo=zoo_mo[!is.na(zoo_mo$FoodItem),]
zoo_mo=zoo_mo[!is.na(zoo_mo$Desirability),]
str(zoo_mo)
zoo_mo$Sex=as.factor(zoo_mo$Sex)
zoo_mo$Success=as.factor(zoo_mo$Success)
#dummy code Success: 0=unsuccessful, 1=successful.
zoo_mo$Success=as.numeric(zoo_mo$Success)
zoo_mo$Success[zoo_mo$Success==1]<-0
zoo_mo$Success[zoo_mo$Success==2]<-1
hist(zoo_mo$ExactAge)
describe(zoo_mo$ExactAge)
hist(log(zoo_mo$ExactAge))
describe(log(zoo_mo$ExactAge))
#nice, just keep eaxct age as it is
hist(zoo_mo$Complexity)
describe(zoo_mo$Complexity)
describe(sqrt(zoo_mo$Complexity))
#keep it as Complexity.
hist(zoo_mo$Rarity)
describe(zoo_mo$Rarity)
hist(sqrt(wild_mo$Rarity))
describe(log(zoo_mo$Rarity))
hist(zoo_mo$Desirability)
describe(zoo_mo$Desirability)
#keep the rarity and desirability as they are.
zoo_mo$sqrt.Complexity=sqrt(zoo_mo$Complexity)
#fit the model
zoo<- glmer(Success ~ ExactAge+Sex+Complexity+Rarity+Desirability+(1|FoodItem)+
            (0+Complexity|FoodItem)+(0+Rarity|FoodItem)+(0+Desirability|FoodItem),
            family=binomial,data=zoo_mo,control=contr)
# Check residuals and residuals vs. fitted vallues.
hist(residuals(zoo))
qqplot(residuals(zoo), rnorm(length(residuals(zoo))))
qqline(residuals(zoo), rnorm(length(residuals(zoo))),col = "dodgerblue", lwd = 2)
plot(fitted(zoo),residuals(zoo))
#to get LRT, df, and p results:
drop1(zoo,test="Chisq")
#to get estimates and SE
round(summary(zoo)$coefficients,3)
#to get sd. for random effects:
summary(zoo)$varcor
#no significant result.
#ICs
int1<- predictorEffect("ExactAge",zoo)
summary(as.data.frame(int1))
int2<- predictorEffect("Sex",zoo)
summary(as.data.frame(int2))
int3<- predictorEffect("Complexity",zoo)
summary(as.data.frame(int3))
int4<- predictorEffect("Rarity",zoo)
summary(as.data.frame(int4))
int5<- predictorEffect("Desirability",zoo)
summary(as.data.frame(int5))
#target�s relation to the beggar: because captive ones are with their relatives for most of the time a day in close distance so I expect them to beg from different individuals more often than the wild ones).
mycols<-colors()[c(10,19,72,143,373,419,516,642)]
relatizoo<- table(zooage$RelationtoB)
Desire<-pie3D(relatizoo,theta=pi/4,col=mycols,explode=0.1,labels=names(relatizoo)) 
relatiwild<- table(wild$TargetRelation)
Desire<-pie3D(relatiwild,theta=pi/4,col=c("lightgreen","beige"),explode=0.1,labels=names(relatiwild)) 
#################################################part two##############################################################################################
#full model: model ii
full_ana<-read.delim("Data I_Full.txt", header=T, sep="\t",na.strings=c("", "NA"))
str(full_ana) 
# subset the data with the begging targets being the mothers only.
full_mo<-subset(full_ana,RelationtoB=="mother")
str(full_mo)
full_mo=full_mo[!is.na(full_mo$Success),]
full_mo=full_mo[!is.na(full_mo$ExactAge),]
full_mo=full_mo[!is.na(full_mo$FoodItem),]
full_mo=full_mo[!is.na(full_mo$Mother),]
full_mo=full_mo[!is.na(full_mo$Complexity),]
full_mo=full_mo[!is.na(full_mo$Begger),]
full_mo$Success=as.factor(full_mo$Success)
full_mo$Sex<-as.factor(full_mo$Sex)
full_mo$FoodItem<-as.factor(full_mo$FoodItem)
full_mo$Mother<-as.factor(full_mo$Mother)
full_mo$Begger<-as.factor(full_mo$Begger)
full_mo$Site<-as.factor(full_mo$Site)
full_mo$Rarity.Cat<-as.factor(full_mo$Rarity.Cat)
#dummy code Success: 0=unsuccessful, 1=successful.
full_mo$Success=as.numeric(full_mo$Success)
full_mo$Success[full_mo$Success==1]<-0
full_mo$Success[full_mo$Success==2]<-1
contr=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=100000))
full_mo$BeggerAge=as.factor(paste(full_mo$Begger,round(full_mo$ExactAge)))
describe(full_mo$Complexity)
#looking good with the distribution and everything else
hist(sqrt(full_mo$ExactAge))
full_mo$sqrt.Age=sqrt(full_mo$ExactAge)
describe(full_mo$sqrt.Age)
#much better with the distribution, keep it as 'sqrt.Age'
#raw data with age plot
ggplot(full_mo, aes(x =sqrt.Age, y =Success)) +theme(text = element_text(size = 20))+
     geom_jitter(height = 0.01, width = 0) + labs(y="Success (0= unsuccessful, 1= successful)",x = "Age (square root transformed)")+
     geom_smooth(method = "loess",size = 1,col="darkgreen")+theme_bw()+coord_cartesian(ylim = c(0, 1), xlim = c(0.5, 4))
ggplot(full_mo, aes(x =sqrt.Age, y =Success,group=Site,col=Site)) +theme(text = element_text(size = 20))+
     geom_jitter(height = 0.01, width = 0) + labs(y="Success (0= unsuccessful, 1= successful)",x = "Age (square root transformed)")+
     geom_smooth(method = "loess",size = 1)+theme_bw()+coord_cartesian(ylim = c(0, 1), xlim = c(0.5, 4))+scale_fill_manual(values = wes_palette("GrandBudapest2", n = 2))
#this indicates that the relation between the age and success is negative quadratic.
#To see if age has a linear or quadratic effect on success you can compare two models with the anova function:1. Success ~ Age + (1|Individual) and 2. Success~ Age + I(Age^2) + (1|Individual) -> if Nr 2. is preferred you can include age like this in the full model. 
is.ExactAge.linear.v1<- glmer(Success ~ ExactAge + (1 | BeggerAge)+(1|Mother/Begger),family=binomial(link="logit"), data=full_mo, control=contr)
is.ExactAge.linear.v2<- glmer(Success ~ ExactAge + I(ExactAge^2)+(1 | BeggerAge)+(1|Mother/Begger),family=binomial(link="logit"), data=full_mo, control=contr)
anova(is.ExactAge.linear.v1,is.ExactAge.linear.v2,test="Chisq")
##'is.ExactAge.linear.v2' is preferred! So include age as a quadratic variable in the model.
#fit the model
full.x<-glmer(Success ~ sqrt.Age + Site + Sex + sqrt.Age * Sex + Complexity + I(sqrt.Age^2) + 
             (1 | BeggerAge) + (1 | Mother/Begger) + (0 + sqrt.Age | Mother/Begger)+(0 + Sex|Mother/Begger)+
             (1 | FoodItem) + (0 + Complexity | FoodItem),family=binomial(link="logit"),data=full_mo,control=contr)
#control for the rarity variable: Rariy.Cat which has four levels: very low, low, high, very high.
# Check residuals and residuals vs. fitted vallues.
hist(residuals(full.x))
qqplot(residuals(full.x), rnorm(length(residuals(full.x))))
qqline(residuals(full.x), rnorm(length(residuals(full.x))),col = "dodgerblue", lwd = 2)
plot(fitted(full.x),residuals(full.x))
#in the wild data, I took four quantile points (25%,50%,75%,100%) from ranked rarity digits in ascending order. I did this because the zoo data had only four levels (2-5). This way, they are somewhat combinable.  
full_mo=full_mo[!is.na(full_mo$Rarity.Cat),]
str(full_mo)
full.xx<-glmer(Success ~ sqrt.Age + Site + Sex + sqrt.Age * Sex + Complexity + I(sqrt.Age^2) + Rarity.Cat+
             (1 | BeggerAge) + (1 + sqrt.Age+Sex | Mother/Begger)+
             (1 + Complexity+Rarity.Cat| FoodItem) ,family=binomial(link="logit"),data=full_mo,control=contr)
#to get LRT, df, and p results:
drop1(full.x, test="Chisq")
drop1(full.xx, test="Chisq")
#to get estimates and SE
round(summary(full.x)$coefficients,3)
round(summary(full.xx)$coefficients,3)
#to get sd. for random effects:
summary(full.x)$varcor
summary(full.xx)$varcor
#the comparison of full.x and full.xx tells us that in the model with Rarity.Cat, age, age*sex, and site are significant as how they are in the model without Rarity.Cat, and there is not much change in their estimates. 
#obtain CIs
int1<- predictorEffect("sqrt.Age",full.x)
summary(as.data.frame(int1))
int2<- predictorEffect("Sex",full.x)
summary(as.data.frame(int2))
int3<- predictorEffect("Site",full.x)
summary(as.data.frame(int3))
int4<- predictorEffect("Complexity",full.x)
summary(as.data.frame(int4))
#linear prediction (on the y axis) represents aka Least-squares means (Estimated marginal means). 
plot(allEffects(full.x),lines=list(multiline=F,col="black"), ylab="Probability of Begging Success", selection=1,text = element_text(size = 30)) #the site variable
plot(allEffects(full.x), lines=list(multiline=F,col="darkgreen"),xlab="Age(square root transformed)", ylab="Probability of Begging Success", selection=3) #the age variable
#age * sex effect on begging success.
a.s <- predictorEffect("sqrt.Age",full.x)
plot(a.s, lines=list(multiline=TRUE,col=c("magenta","blue")), confint=list(style="auto"),xlab="Age (square root transformed)", ylab="Probability of Begging Success")
#age and site effect on begging success.
full.as<-glmer(Success ~ sqrt.Age + Site + Sex +sqrt.Age *Site + Complexity + I(sqrt.Age^2) +Rarity.Cat+ 
              (1 | BeggerAge) + (1 | Mother/Begger) + (0 + sqrt.Age | Mother/Begger)+
              (1 | FoodItem) + (0 + Complexity | FoodItem)+(0 + Site | FoodItem)+(0+Rarity.Cat|FoodItem),family=binomial(link="logit"),data=full_mo,control=contr)
drop1(full.as,test="Chisq")
#success~age in two sites
a.s0<- predictorEffect("sqrt.Age",full.as)
plot(a.s0, lines=list(multiline=TRUE), confint=list(style="auto"),xlab="Age (square root transformed)", ylab="Probability of Begging Success")
###########################################################################################################################################
#discussion point: should one include the quadratic age variable interacting with sex variable?
interaction.x<- glmer(Success ~ sqrt.Age + Sex + sqrt.Age * Sex + Complexity + sqrt.Rarity+I(sqrt.Age^2)*Sex + I(sqrt.Age^2)+
            (1|BeggerAge) + (1|Mother/Begger.id) + 
            (0 + sqrt.Age|Mother/Begger.id) +(0 + Sex|Mother/Begger.id)+(1|FoodItem) + 
            (0 + Complexity | FoodItem)+(0 + sqrt.Rarity| FoodItem),family=binomial(link="logit"),
            data=wild_mo,control=contr)
full.x2<-glmer(Success ~ sqrt.Age + Site + Sex + sqrt.Age * Sex + Complexity + I(sqrt.Age^2)*Sex +I(sqrt.Age^2)+ 
             (1 | BeggerAge) + (1 | Mother/Begger) + (0 + sqrt.Age | Mother/Begger)+(0 + Sex|Mother/Begger)+
             (1 | FoodItem) + (0 + Complexity | FoodItem),family=binomial(link="logit"),data=full_mo,control=contr)
drop1(interaction.x, test="Chisq")
drop1(full.x2, test="Chisq")
#model comparison:
anova(interaction,interaction.x,test="Chisq")
anova(full.x,full.x2,test="Chisq")
#they don't differ. Therefore, model 'interaction' and 'full.x' are kept.
######################################################part three###########################################################################
##########################################################################################
#For Begging Frequencies & Begging Rates Computations Only: four Gaussian models in total#
##########################################################################################
# read my full table for the purpose of analyses (full_ana). 
con<-read.delim("Data IV1_Condensed.txt", header=T, sep="\t",na.strings=c("", "NA"))
str(con) 
zoocon<-read.delim("Data IV2_Zoo_condensed.txt", header=T, sep="\t",na.strings=c("", "NA"))
str(zoocon) 
conzoowild<-read.delim("Data IV3_Condensed_zoowildcompar.txt", header=T, sep="\t",na.strings=c("", "NA"))
str(conzoowild)
############################################################################################################################################
#the followings contains three models: wild, zoo, and full models                                                                          #            
#important: in the following, "Begger" always refers to "Focal"; "Rarity" always refers to the "Frequency" of the food item in this thesis #            
############################################################################################################################################
#model iv & vii: begging frequency ~ Age + Sex + Complexity + Rarity (iv)& begging rate (vii)~ same effects 
#begging frequency (model iv).
# handle the missing data 
con=con[!is.na(con$BeggingFrequency),]
con=con[!is.na(con$AgeClass),]
con=con[!is.na(con$Sex),]
con=con[!is.na(con$Complexity),]
con=con[!is.na(con$Rarity),]
con=con[!is.na(con$FoodItem),]
str(con)
con$FoodItem=as.factor(con$FoodItem)
con$Sex=as.factor(con$Sex)
con$BeggerAge=as.factor(paste(con$Begger,round(con$AgeClass)))
#check the disribution of the DM
hist(con$BeggingFrequency)
describe(con$BeggingFrequency)
hist(con$BeggingRate)
describe(con$BeggingRate)
#both very skewed so let's log transform it
hist(log(con$BeggingFrequency))
describe(log(con$BeggingFrequency))
#inspect the distribution of all the covariates 
hist(con$AgeClass)
describe(con$AgeClass)
describe(sqrt(con$AgeClass))
con$sqrt.Age=sqrt(con$AgeClass)
hist(con$Complexity)
describe(con$Complexity)
describe(con$Rarity)
describe(log(con$Rarity))
#keep the log one!
con$log.Rarity=log(con$Rarity)
#this is okay-ish, keep it like this!
con$log.BeggingFrequency=log(con$BeggingFrequency)
full.bf.rs=lmer(log.BeggingFrequency~sqrt.Age+Complexity+Sex+log.Rarity+(1|BeggerAge)+(1+sqrt.Age+Sex|Mother/Begger)+(1+Complexity+log.Rarity|FoodItem), data=con,REML=F)
# Check residuals and residuals vs. fitted vallues.
hist(residuals(full.bf.rs))
qqplot(residuals(full.bf.rs), rnorm(length(residuals(full.bf.rs))))
qqline(residuals(full.bf.rs), rnorm(length(residuals(full.bf.rs))),col = "dodgerblue", lwd = 2)
plot(fitted(full.bf.rs), residuals(full.bf.rs))
#to get LRT, df, and p values
drop1(full.bf.rs, test="Chisq")
#to get estimates and SE
round(summary(full.bf.rs)$coefficients,3)
#to get sd. for random effects
summary(full.bf.rs)$varcor
#to get CIs for begging frequency model:
int1<- predictorEffect("sqrt.Age",full.bf.rs)
summary(as.data.frame(int1))
int2<- predictorEffect("Complexity",full.bf.rs)
summary(as.data.frame(int2))
int3<- predictorEffect("Sex",full.bf.rs)
summary(as.data.frame(int3))
int4<- predictorEffect("log.Rarity",full.bf.rs)
summary(as.data.frame(int4))
#inspect the relation from the raw data.
#
ggplot(con, aes(x =Complexity, y =log.BeggingFrequency)) +theme(text = element_text(size = 20)) +
     geom_point() + labs(y="Begging Frequency (log transformed)",x = "Complexity")+
     geom_smooth(method = 'lm',size = 1,col="purple")+theme_bw()
#
ggplot(con, aes(x =log.Rarity, y =log.BeggingFrequency)) +theme(text = element_text(size = 20)) +
     geom_point() + labs(y="Begging Frequency (log transformed)",x = "Frequency of the food item (log transformed)")+
     geom_smooth(method = 'lm',size = 1,col="purple")+theme_bw()
#
ggplot(con, aes(x =AgeClass, y =BeggingFrequency)) +theme(text = element_text(size = 20)) +
     geom_point() + labs(y="Begging Frequency",x = "Age Class")+ggtitle("begging frequency ~ age of the wild data (raw data)")+
     geom_smooth(method = 'lm',size = 1,col="cyan")+theme_bw()
#
ggplot(con, aes(x =sqrt.Age, y =log.BeggingFrequency)) +theme(text = element_text(size = 20)) +
     geom_point() + labs(y="Begging Frequency (log transformed)",x = "Age Class (square root transformed)")+ggtitle("begging frequency ~ age of the wild data (transformed data)")+
     stat_smooth(method = 'lm',size = 1,col="cyan")+theme_bw()
######################################################################################
#begging rate (model vii)
con<-read.delim("Data IV1_Condensed.txt", header=T, sep="\t",na.strings=c("", "NA"))
str(con)
con=con[!is.na(con$AgeClass),]
con=con[!is.na(con$Sex),]
con=con[!is.na(con$Complexity),]
con=con[!is.na(con$Rarity),]
con=con[!is.na(con$FoodItem),]
str(con)
con$FoodItem=as.factor(con$FoodItem)
con$Sex=as.factor(con$Sex)
con$BeggerAge=as.factor(paste(con$Begger,round(con$AgeClass)))
con=con[!is.na(con$BeggingRate),]
describe(con$BeggingRate)
con$log.BeggingRate=log(con$BeggingRate)
describe(log.BeggingRate)
con$sqrt.Age=sqrt(con$AgeClass)
con$log.Rarity=log(con$Rarity)
full.br.rs=lmer(log.BeggingRate~sqrt.Age+Complexity+Sex+log.Rarity+(1|BeggerAge)+(1+sqrt.Age+Sex|Mother/Begger)+(1+Complexity+log.Rarity|FoodItem), data=con,REML=F)
#it converged, so there is no need to z.transformation.
#collineraty
xx1=lm(log.BeggingFrequency~sqrt.Age+Complexity+Sex+log.Rarity,data=con)
vif(xx1)
x2=lm(log.BeggingRate~sqrt.Age+Complexity+Sex+log.Rarity,data=con)
vif(x2)
# Check residuals and residuals vs. fitted vallues.
hist(residuals(full.br.rs))
qqplot(residuals(full.br.rs), rnorm(length(residuals(full.br.rs))))
qqline(residuals(full.br.rs), rnorm(length(residuals(full.br.rs))),col = "dodgerblue", lwd = 2)
plot(fitted(full.br.rs), residuals(full.br.rs))
#there is no issue!
#to get LRT, df, and p values
drop1(full.br.rs, test="Chisq")
#to get estimates and SE
round(summary(full.br.rs)$coefficients,3)
#to get sd. for random effects
summary(full.br.rs)$varcor
#to get CIs for begging rate model:
int1<- predictorEffect("sqrt.Age",full.br.rs)
summary(as.data.frame(int1))
int2<- predictorEffect("Complexity",full.br.rs)
summary(as.data.frame(int2))
int3<- predictorEffect("Sex",full.br.rs)
summary(as.data.frame(int3))
int4<- predictorEffect("log.Rarity",full.br.rs)
summary(as.data.frame(int4))
#it does work this time!
#inspect the relation from the raw data.
#
ggplot(con, aes(x =log.Rarity, y =log.BeggingRate)) +theme(text = element_text(size = 15)) +
     geom_point() + labs(y="Begging Rate (log transformed)",x = "Frequency of the food item (log transformed)")+
     geom_smooth(method = 'lm',size = 1,col="purple")+theme_bw()
##############################################################################################################################
#model v: begging frequency (~ age + Sex + Complexity + Rarity + Desirability
zoocon=zoocon[!is.na(zoocon$Rarity),]
str(zoocon)
#check the disribution of the DM
hist(zoocon$BeggingFreq)
describe(zoocon$BeggingFreq)
#both very skewed so let's log transform it
hist(log(zoocon$BeggingFreq))
describe(log(zoocon$BeggingFreq))
#this is okay ish, keep it like these!
zoocon$log.BeggingFrequency=log(zoocon$BeggingFreq)
hist(zoocon$AgeClass)
describe(zoocon$AgeClass)) #just keep it although not perfectly ideal
hist(zoocon$Complexity)
describe(zoocon$Complexity)
hist(zoocon$Rarity)
describe(zoocon$Rarity)
hist(zoocon$Desirability)
describe(zoocon$Desirability)
full.z=lmer(log.BeggingFrequency~AgeClass+Complexity+Sex+Rarity+Desirability+(1|Species_Item_Simple), data=zoocon,REML=F)
# Check residuals and residuals vs. fitted vallues.
hist(residuals(full.z))
qqplot(residuals(full.z), rnorm(length(residuals(full.z))))
qqline(residuals(full.z), rnorm(length(residuals(full.z))),col = "dodgerblue", lwd = 2)
plot(fitted(full.z), residuals(full.z))
#collineraty
xx=lm(log.BeggingFrequency~AgeClass+Complexity+Sex+Rarity+Desirability,data=zoocon)
vif(xx)
#there is no issue!
#get LRT, df, and p values.
drop1(full.z, test="Chisq")
#to get estimates and SE
round(summary(full.z)$coefficients,3)
#to get sd. for random effects
summary(full.z)$varcor
#to get CIs
int1<- predictorEffect("AgeClass",full.z)
summary(as.data.frame(int1))
int2<- predictorEffect("Complexity",full.z)
summary(as.data.frame(int2))
int3<- predictorEffect("Sex",full.z)
summary(as.data.frame(int3))
int4<- predictorEffect("Rarity",full.z)
summary(as.data.frame(int4))
int5<- predictorEffect("Desirability",full.z)
summary(as.data.frame(int5))
#it does work!
#plot the significant results: age class and Rarity
plot(allEffects(full.z), ylab="log(Probability of Begging Frequency)", selection=1)
plot(allEffects(full.z), ylab="log(Probability of Begging Frequency)", selection=4)
#plot the raw data as well
#
ggplot(zoocon, aes(x =AgeClass, y =log.BeggingFrequency)) +theme(text = element_text(size = 15)) +
     geom_point() + labs(y="Begging Frequency (log transformed)",x = "Age Class")+
     geom_smooth(method = 'lm',size = 1,col="cyan")+theme_bw()
#
ggplot(zoocon, aes(x =Rarity, y =log.BeggingFrequency)) +theme(text = element_text(size = 15)) +
     geom_point() + labs(y="Begging Frequency (log transformed)",x = "Frequency of the food item")+
     geom_smooth(method = 'lm',size = 1,col="cyan")+theme_bw()
###############################################################################################################
#descriptive plots 
#a visualizaion of how much data (how many follow hours) we have available for each age class and sex.
#with wild data (data: con)
con<-read.delim("Data IV1_Condensed.txt", header=T, sep="\t",na.strings=c("", "NA"))
str(con)
con=con[!is.na(con$AgeClass),]
con=con[!is.na(con$FollowHours),]
con$AgeClass=as.factor(con$AgeClass)
ggplot() + theme_bw()+geom_bar(aes(y = FollowHours, x =AgeClass, fill = Sex), 
data = con,stat="identity",na.rm=TRUE,position = "dodge")+theme(text = element_text(size = 15))+
scale_fill_manual(values = wes_palette("GrandBudapest2", n = 2))+ labs(y="Follow Hours",x = "Age Class")
#with zoo data (zoocon)
zoocon<-read.delim("Data IV2_Zoo_condensed.txt", header=T, sep="\t",na.strings=c("", "NA"))
str(zoocon)
zoocon$AgeClass=as.factor(zoocon$AgeClass)
ggplot() + theme_bw()+geom_bar(aes(y = FollowHours, x =AgeClass, fill = Sex), 
data = zoocon,stat="identity",na.rm=TRUE,position = "dodge")+theme(text = element_text(size = 15))+
scale_fill_manual(values = wes_palette("GrandBudapest2", n = 2))+ labs(y="Follow Hours",x = "Age Class")
################################################################################################################
#model vi: Begging Frequency ~ Age + Sex + Complexity +Site (conzoowild)
# handle the missing data 
conzoowild=conzoowild[!is.na(conzoowild$AgeClass),]
conzoowild=conzoowild[!is.na(conzoowild$Sex),]
conzoowild=conzoowild[!is.na(conzoowild$Complexity),]
conzoowild=conzoowild[!is.na(conzoowild$Site),]
conzoowild=conzoowild[!is.na(conzoowild$FoodItem),]
conzoowild=conzoowild[!is.na(conzoowild$BeggingFrequency),]
str(conzoowild)
conzoowild$BeggerAge=as.factor(paste(conzoowild$Begger,round(conzoowild$AgeClass)))
#check the disribution of the DM
hist(conzoowild$BeggingFrequency)
describe(conzoowild$BeggingFrequency)
#very skewed so let's log transform it
hist(log(conzoowild$BeggingFrequency))
describe(log(conzoowild$BeggingFrequency))
#this is okay-ish, keep it like this
conzoowild$log.BeggingFrequency=log(conzoowild$BeggingFrequency)
hist(sqrt(conzoowild$AgeClass))
describe(sqrt(conzoowild$AgeClass))
#since not that different, keep the original
hist(conzoowild$Complexity)
describe(conzoowild$Complexity)
#keep it as it is
#z transform all the covariates
conzoowild$z.AgeClass=as.vector(scale(conzoowild$AgeClass))
conzoowild$z.Complexity=as.vector(scale(conzoowild$Complexity))
describe(conzoowild$z.AgeClass)
describe(conzoowild$AgeClass)
#just keep the original ones for now, use those z-transformed ones in case the model doesn't converge.
#random intercepts are mother/begger begger age and food item.
full.rs=lmer(log.BeggingFrequency~z.AgeClass+z.Complexity+Sex+Site+(1|BeggerAge)+(1+z.AgeClass+Sex|Mother/Begger)+(1+z.Complexity|FoodItem),data=conzoowild,REML=F)
# Check residuals and residuals vs. fitted vallues.
hist(residuals(full.rs))
qqplot(residuals(full.rs), rnorm(length(residuals(full.rs))))
qqline(residuals(full.rs), rnorm(length(residuals(full.rs))),col = "dodgerblue", lwd = 2)
plot(fitted(full.rs), residuals(full.rs))
#collineraty
xx=lm(log.begfreq~z.AgeClass+z.Complexity+Sex+Site,data=conzoowild)
vif(xx)
#there is no issue
summary(full.rs)
#let's see all the effects --> to get LRT, df, and p values.
drop1(full.rs, test="Chisq")
#to get estimates and SE
round(summary(full.rs)$coefficients,3)
#to get sd. for random effects
summary(full.rs)$varcor
#to get CIs
int1<- predictorEffect("z.AgeClass",full.rs)
summary(as.data.frame(int1))
int2<- predictorEffect("z.Complexity",full.rs)
summary(as.data.frame(int2))
int3<- predictorEffect("Sex",full.rs)
summary(as.data.frame(int3))
int4<- predictorEffect("Site",full.rs)
summary(as.data.frame(int4))
#it does work!
#plot Site ~ begging frequency using real values.
ggplot(conzoowild, aes(x=Site, y=log.BeggingFrequency)) +
  geom_boxplot(color="black")+theme(text = element_text(size = 20),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA))+labs(y="Begging Frequency (log transformed)",x = "Site")+
  geom_jitter(position=position_jitter(0.2))+theme_bw()
#
#to inspect the relation between the age and begging frequency.  
ggplot(conzoowild, aes(x =AgeClass, y =log.BeggingFrequency)) +theme(text = element_text(size = 20)) +
     geom_point() + labs(y="Begging Frequency (log transformed)",x = "Age Class")+
     geom_smooth(method = 'lm',size = 1,col="cyan")+theme_bw()
#############################################################the end###########################################################################



